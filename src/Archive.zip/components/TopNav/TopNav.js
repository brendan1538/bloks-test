import React, { useState, useEffect } from 'react';
import { connect } from 'react-redux';
import { animateScroll as scroll } from 'react-scroll';

import { activePage } from '../../redux/actions/actions';

import './TopNav.css';

const TopNav = () => {

    const [state, setState] = useState({
        isDesktop: false
    });

    useEffect(() => {
        window.addEventListener('resize', setState({isDesktop: window.innerWidth > 768}))
    }, []);

    return(
        <section className="top-nav">
            {state.isDesktop ? (
            <ul>
                <li><h2 onClick={() => {scroll.scrollTo(window.innerHeight * 0); activePage(1); }} className="nav-link">About</h2></li>
                <li><h2 onClick={() => {scroll.scrollTo(window.innerHeight * 0.7); activePage(2); }} className="nav-link">Projects</h2></li>
                <li><h2 onClick={() => {scroll.scrollTo(window.innerHeight * 1.7); activePage(3); }} className="nav-link">Contact</h2></li>
            </ul>
            ) : (
            <ul>
                <li><h2 onClick={() => {scroll.scrollTo(window.innerHeight * 0); activePage(1); }} className="nav-link">About</h2></li>
                <li><h2 onClick={() => {scroll.scrollTo(window.innerHeight * 0.48); activePage(2); }} className="nav-link">Projects</h2></li>
                <li><h2 onClick={() => {scroll.scrollTo(window.innerHeight * 1.6); activePage(3); }} className="nav-link">Contact</h2></li>
            </ul>
            )}
            
        </section>
    )
}
const mapDispatchToProps = dispatch => {
	return {
		activePage: (id) => dispatch(activePage(id))
	};
};

export default connect(mapDispatchToProps)(TopNav);